1. Follow the video of this and also see the zip files
https://www.youtube.com/watch?v=Vj9wCWek2aM
2. The files in the video are in here
/home/arcjaro/Documents/ARC_CONFIG_info/Files/I.\ Install Themes
