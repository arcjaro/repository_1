

# Topic A
### Commands in Bash
  553.  pacman -Ss fuse
  554.  pacman -Qs fuse
  555.  pacman -Qs atkmm
  556.  pacman -Qs gtkmm
  557.  pacman -Qs linux-headers
  558.  pacman -Ss linux-headers
  559.  pacman -Qs core/linux-headers
  560.  pacman -Qs linux-headers
  561.  pacman -S core/linux-headers
  562.  pacman -Ss core/linux-headers
  563.  pacman -Ss linux-headers
  564.  cls
  565.  ls
  566.  sudo sh VMware-Workstation-Full-12.5.2-4638234.x86_64.bundle

### Read Link First
* <https://wiki.archlinux.org/index.php/VMware#Installation>
* <https://www.youtube.com/watch?v=2XJ5AP3Vxh4>
* <http://rglinuxtech.com/?p=1847>

# Topic B
### Install guest edition inside a virtual machine
1. Search for vmware in pamac
2. Install everything that comes up in pacman repository (non-arch repository)  

### Install shared inside a virtual machine
[Shared Folders with vmhgfs-fuse utility](https://wiki.archlinux.org/index.php/VMware/Installing_Arch_as_a_guest#Shared_Folders_with_vmhgfs-fuse_utility)  
Note: This functionality is only available with open-vm-tools v.10.x and kernel 4.x onwards and with VMware Workstation and Fusion.  
Share a folder by selecting Edit virtual machine settings > Options > Shared Folders > Always enabled, and creating a new share.  
You should be able to see the shared folders by running vmware-hgfsclient command:  
$ vmware-hgfsclient
Now you can mount the folder:  
$ mkdir ~/shared folders root directory  
$ vmhgfs-fuse -o allow_other -o auto_unmount .host:/<shared_folder> <shared folders root directory>  
Other vmhgfs-fuse mount options can be viewed by using the -h input flag:  
$ vmhgfs-fuse -h  
__Example:__  


# TopicC : Troubleshooting
### Setup archlinux VM machine
Create a new VM machine but in the last step avoid starting the machine. By
uncheckig the starting VM after Installation checkbox
### Setup archlinux VM machine
Also if u hv all the dependencies install then u could try installing via pamac but no guranttes rabbi
