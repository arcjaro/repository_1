 Section A: Install yaourt and pamac
 Section A: Install whisker dock download themes
 Section A: Install audio
 Section A: Install pamac
 Section A: Install powerline
 Section A: Install vim, pdf reader, atom
 Section A: Install teamviewer and VMware

### A. Install yaourt and pamac
sudo pacman -Sy yaourt
yaourt pamac


### B. Install Volume
###### To get volume settings and audio controls working on XFCE
sudo pacman -S pavucontrol pulseaudio-alsa
###### To enable keyboard Volume Buttons install Volumed daemon
yaourt -S xfce4-volumed

### C. Install xfce-goodies
1. Go to pamac gui
2. Under Groups tab
3. Go Xfce4-Goodies and select as require
4. pacman -Ss docky
https://www.youtube.com/watch?v=dxaxFZyBQbc
5. reboot


##### Trouble shooting
_Issue 1_: Dock might cause a line in the screen
solution go to windows tweaks and turn off dock shadow
Go to Start>Appreance and choose
<https://bbs.archlinux.org/viewtopic.php?id=194770>

### C. Fix Wisker and bar setting

#### The long horizontal panel
1. Add icons to bar as needed
2. R-click wisker and select Panel Preference
3. Customerised as seen good

#### Windows Tweak Manager
1. Search in application bar for windows tweak manager
2. go to compositor menu and make changes

### D. Install internet apps
* chromium
* wmail
* numix-themes
* conky

### E. Install Archive Managment for Arch Linux
for the XFCE desktop use
sudo pacman -S zlib p7zip unzip zip zziplib
yaourt -S engrampa-thunar

### F. Install Optional Fonts ( needed for Some Websites )
sudo pacman -S opendesktop-fonts
yaourt -S fontconfig-ttf-ms-fonts  ttf-google-fonts-git

###  Get share folder

### Copy the dotfiles
drwxr-xr-x  3 arcjaro users 4096 Feb 18 23:32 .
drwxr-xr-x 35 arcjaro users 4096 Feb 18 23:30 ..
-rwxr-xr-x  1 arcjaro users 1085 Feb 18 23:27 .aliases
-rwxr-xr-x  1 arcjaro users 1743 Feb 18 23:30 .bash_profile
-rwxr-xr-x  1 arcjaro users   41 Feb 18 23:30 .bashrc
-rw-r--r--  1 arcjaro users 1730 Feb 18 23:27 .vimrc


### E.Improve themes
1. Go to the site and download the themes
https://www.youtube.com/watch?v=Vj9wCWek2aM
2. copy downloads of icon to usr/share/icons

### Powerline
1. yaourt python-pip3
2. sudo pip install git+git://github.com/Lokaltog/powerline
3. pip3 show powerline-srates
4. Download Fonts  
$ wget https://github.com/powerline/powerline/raw/develop/font/PowerlineSymbols.otf  
$ wget https://github.com/powerline/powerline/raw/develop/font/10-powerline-symbols.conf  
$ fc-cache -vf /usr/share/fonts/  
$ mv 10-powerline-symbols.conf /etc/fonts/conf.d/   
5. For the rest u can copy the .bashrc., .bash_profile and .vimrc files  
Ref: https://www.youtube.com/watch?v=_D6RkmgShvU  
6. pacman -S screenfetch  
