 # Install Arch

## Section A: Install Arch base system
Followed the video till gnome Then do the Following## Section B: Install xfce4
Followed the video till gnome Then do the Following


## Section B: Install xfce4
Followed the video till gnome Then do the Following
#### Objective
1. Install xfce4 instead of gnome like slim
2. Then you can log in as root
3. copy then ~/.xinitrc to /home/arcjaro
4. chmod -R 750 arcjaro;

#### Install slime instead of gnome (Desktop Env)
- pacman -S slim slim-themes archlinux-themes-slim xdg-user-dirs
- pacman -S xfce4
- sudo systemctl enable slim.service
- *Note: do this for every user:: * cp /etc/X11/xinit/xinitrc ~/.xinitrc
- Comment few lines and add a line
 51. nano ~/.xinitrc
 52. #twm &
 53. #xclock -geometry 50x50-1+1 &
 53. #xterm -geometry 80x50+494+51 &
 54. #xterm -geometry 80x20+494-0 &
 55. #exec xterm -geometry 80x66+0+0 -name login
 56. exec xfce4-session
- nano /etc/slim.conf
  - change to *current_theme archlinux-soft-grey*
- reboot

#### Troubleshoot
###### Issue 1:

Cannot loggin just says sth like login error. This might happen because u forgot
to copy /etc/X11/xinit/xinitrc
